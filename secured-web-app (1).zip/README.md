# Secured Web Application

## Setup Instructions:

1. Install dependencies:
```
pip3 install -r requirements.txt
```

2. Create MySQL database:
- Login to MySQL and run the commands in `database.sql`

3. Run the app:
```
python3 app.py
```

4. Open in browser:
- http://localhost:5000 → Login
- http://localhost:5000/register → Register

## Features:
- Password hashing using bcrypt
- Secure login system with SQL injection protection
