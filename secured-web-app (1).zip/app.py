from flask import Flask, request, render_template
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt

app = Flask(__name__)
bcrypt = Bcrypt(app)

# MySQL Config
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'secureapp'

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed = bcrypt.generate_password_hash(password).decode('utf-8')

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users(username, password) VALUES(%s, %s)", (username, hashed))
        mysql.connection.commit()
        cur.close()
        return "Registered Successfully"
    return render_template('register.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    cur = mysql.connection.cursor()
    result = cur.execute("SELECT * FROM users WHERE username = %s", (username,))
    if result > 0:
        user = cur.fetchone()
        if bcrypt.check_password_hash(user[2], password):
            return "Login Success"
        else:
            return "Wrong password"
    return "User not found"

if __name__ == '__main__':
    app.run(debug=True)
